
const projectName = 'portfolio';
